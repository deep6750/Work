/*
public abstract class sortAbstractClass {
	abstract void mySort(int arr[]);
}


class mySort extends sortAbstractClass {
	void mySort(int arr[]) {
		return;
	}
	
	public static void main(String args[]) {
		mySort srt = new mySort();
		int arr[] = new int[] {1, 4, 3};
		
		System.out.println("Hola");
		srt.mySort(arr);
	}
}
*/